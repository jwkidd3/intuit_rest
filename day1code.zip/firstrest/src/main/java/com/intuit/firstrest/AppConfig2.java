package com.intuit.firstrest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("v2")
public class AppConfig2 extends Application{

}
