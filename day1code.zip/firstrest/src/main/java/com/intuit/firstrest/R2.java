package com.intuit.firstrest;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

@Path("r2/{name}")
public class R2 {
	
	public R2() {
		System.out.println("Created R2....");
	}
	
	@PathParam("name")
	private String name;
	
	
	@Context
	private HttpHeaders headers;
	
	@Context
	private HttpServletRequest req;

	@GET
	//@Consumes(MediaType.TEXT_PLAIN)
	@Produces({"application/piglatin"})
	public String m1()
	{
		return "R2-M1 -> " + name+" -> "+ headers.getHeaderString("user-agent");
	}
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public String m2()
	{
		return "Consumes JSONL R2-M1";
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,"application/klingon"})
	public String m3()
	{
		return "Produces JSON R2-M1";
	}
}
