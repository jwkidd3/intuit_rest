package com.intuit.firstrest;

import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@Path("r1")
public class R1 {
	
	public R1() {
		System.out.println("Created R1");
	}
	
	@GET
	public String m1() {
		return "Yo REST @ Intuit!";
	}
	
	@GET
	@Path("sample")
	public String m2() {
		return "this is m2";
	}
	
	@DELETE
	@Path("sample")
	public String m3() {
		/*
		 * Backend service called to delete something
		 */
		return "You just deleted....";
	}
	
	@GET
	@Path("bubba")
	public String m2(@DefaultValue("5")@QueryParam("id")int id) {
		return "your id: " + id;
	}
	
	@GET
	@Path("bubba/{id}")
	public String m2(@PathParam("id")String id) {
		return "string path param your id: " + id;
	}
	
	@GET
	@Path("bubba/{id: \\d+}")
	public String m3(@PathParam("id")int id) {
		return "int path param your id: " + id;
	}
	

}
