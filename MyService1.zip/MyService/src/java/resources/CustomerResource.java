package resources;

import entity.Customer;
import entity.CustomerTable;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ws.rs.DELETE;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("Customers")
public class CustomerResource {

    private static final Pattern SEARCH_PATTERN = Pattern.compile("(\\w+)\\.(\\w+)\\.(.+)");
    @Context
    private UriInfo context;

    public CustomerResource() {
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getCustomers(@QueryParam("query") String query) {
        StringBuilder sb = new StringBuilder();
        List<Customer> lc = null;
        if (query == null) {
            lc = CustomerTable.getAll();
        } else {
            Matcher m = SEARCH_PATTERN.matcher(query);
            if (m.matches()) {
                String field = m.group(1);
                String operation = m.group(2);
                String operand = m.group(3);
                lc = CustomerTable.findByFieldMatch(field, operation, operand);
            } else {
                sb.append("Badly formed search parameter...");
            }
        }

        if (lc != null) {
            sb.append("Customers:\n");
            for (Customer c : lc) {
                sb.append(" - ").append(c.toString()).append('\n');
            }
        }
        return sb.toString();
    }
    
    @GET
    @Path("{id: \\d+}")
    public String getOneCustomer(@PathParam("id") int id) {
        return CustomerTable.findByPrimaryKey(new UUID(0, id)).toString();
    }
    
    @DELETE
    @Path("{id: \\d+}")
    public void deleteOneCustomer(@PathParam("id") int id) {
        CustomerTable.removeByPrimaryKey(new UUID(0, id));
    }
}
