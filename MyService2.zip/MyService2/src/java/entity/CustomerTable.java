package entity;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CustomerTable {

    private static Map<UUID, Customer> data = new HashMap<UUID, Customer>();

    static {
        for (Customer x : new Customer[]{
            new Customer(new UUID(0, 1), "Fred Jones", "Here", 10),
            new Customer(new UUID(0, 2), "Jim Smith", "There", 100),
            new Customer(new UUID(0, 3), "Bill Bonner", "Where", 20),
            new Customer(new UUID(0, 4), "Sheila Williams", "In Town", 5000),
            new Customer(new UUID(0, 5), "Ella Barnard", "Countryside", 800),
            new Customer(new UUID(0, 6), "Freda Fredricksson", "Uphill", 700),
            new Customer(new UUID(0, 7), "Christine Farrow", "Down Dale", 2000)
        }) {
            data.put(x.getId(), x);
        }
    }

    public static boolean update(Customer c) {
        return data.put(c.getId(), c) != null;
    }
    
    public static List<Customer> getAll() {
        List<Customer> rv = new LinkedList<Customer>();
        for (Map.Entry<UUID, Customer> e : data.entrySet()) {
            rv.add(e.getValue());
        }
        return rv;
    }

    public static Customer findByPrimaryKey(UUID pk) {
        return data.get(pk);
    }

    public static List<Customer> findByFieldMatch(String field, String operation, String value) {
        List<Customer> rv = new LinkedList<Customer>();
        for (Map.Entry<UUID, Customer> e : data.entrySet()) {
            Customer c = e.getValue();

            String target;
            switch (field) {
                case "name":
                    target = c.getName();
                    break;
                case "address":
                    target = c.getAddress();
                    break;
                case "creditLimit":
                    target = "" + c.getCreditLimit();
                    break;  
                default:
                    throw new IllegalArgumentException("No such field: " + field);
            }
            boolean match = false;
            switch (operation.toLowerCase()) {
                case "eq":
                    match = target.equals(value);
                    break;
                case "ne":
                    match = !target.equals(value);
                    break;
                case "cont":
                    match = (target.indexOf(value) != -1);
                    break;
                case "ncont":
                    match = (target.indexOf(value) == -1);
                    break;
                default:
                    throw new IllegalArgumentException("No such operation: " + operation);
            }
            if (match) {
                rv.add(e.getValue());
            }
        }
        return rv;
    }

    public static boolean removeByPrimaryKey(UUID uuid) {
        return data.remove(uuid) != null;
    }
}
