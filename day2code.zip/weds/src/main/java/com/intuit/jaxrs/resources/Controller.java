package com.intuit.jaxrs.resources;

import javax.ws.rs.Path;

import com.intuit.entity.CarManager;

@Path("bubba")
public class Controller {
	

	@Path("")
	public CarManager getManyCars() {
		return new CarManager();

	}
	

	@Path("{vin}")
	public CarManager getCar() {
		return new CarManager();

	}

	

}
