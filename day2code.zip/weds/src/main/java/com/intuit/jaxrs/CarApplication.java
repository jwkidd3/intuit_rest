package com.intuit.jaxrs;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("car")
public class CarApplication extends Application{

}
