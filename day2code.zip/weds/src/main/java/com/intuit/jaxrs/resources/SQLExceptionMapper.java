package com.intuit.jaxrs.resources;

import java.sql.SQLException;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class SQLExceptionMapper implements ExceptionMapper<SQLException> {

	@Override
	public Response toResponse(SQLException exception) {
		ResponseBuilder rb=Response.status(500);
		rb.entity("Something bad happened: "+ exception.getMessage());
		return rb.build();
	}

}
