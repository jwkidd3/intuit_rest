package com.intuit.jaxrs.resources;

import java.sql.SQLException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;

@Path("errors")
public class Controller2 {
	
	@GET
	public String m1() {
		throw new WebApplicationException("No way",505);

	}
	
	@GET
	@Path("sql")
	public String getSQL() throws SQLException {
		throw new SQLException("ORA-050");
	}
	
	@GET
	@Path("num")
	public String getOther() {
		throw new NumberFormatException("Numbers are a big no...");
	}

}
