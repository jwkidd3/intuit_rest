package com.intuit.jaxrs.resources;

import java.io.IOException;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

@Provider
public class SecurityFilter implements ContainerRequestFilter {

	@Override
	public void filter(ContainerRequestContext ctx) throws IOException {
		String auth=ctx.getHeaderString("intuit-auth");
		
		if(auth == null) {
			ctx.abortWith(Response.status(401).
					entity("You cant do that").
					cookie(new NewCookie("cook","oatmeal")).build());
		}
		
	}

}
