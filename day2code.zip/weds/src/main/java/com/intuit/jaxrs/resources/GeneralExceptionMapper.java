package com.intuit.jaxrs.resources;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class GeneralExceptionMapper implements ExceptionMapper<Exception> {

	@Override
	public Response toResponse(Exception exception) {
		ResponseBuilder rb=Response.status(500);
		rb.entity("Something bad happened: "+ exception.getMessage());
		return rb.build();
	}

}
