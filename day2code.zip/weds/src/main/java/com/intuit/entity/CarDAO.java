package com.intuit.entity;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CarDAO {
	Map<String,Car> cars=new HashMap<>();
	public CarDAO() {
		cars.put("1234",new Car("1234","Toyota","Tacoma"));
		cars.put("5678",new Car("5678","Honda","CRV"));
		cars.put("7892",new Car("7892","Ford","F-150"));
	}
	
	public Car getByVin(String vin) {
		return cars.get(vin);
	}
	
	public Collection<Car> getAll(){
		return cars.values();
	}

}
