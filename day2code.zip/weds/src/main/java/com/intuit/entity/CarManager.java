package com.intuit.entity;

import java.util.Collection;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

public class CarManager {
	private CarDAO dao = new CarDAO();
	
	@GET
	public Collection<Car> getCar(@QueryParam("expr") String param) {
		return dao.getAll();

	}
	
	@GET
	@Path("{vin}")
	public Response getByVin(@PathParam("vin") String vin) {

		ResponseBuilder rb = null;
		Car c = dao.getByVin(vin);
		if (c == null)
			rb = Response.status(404).entity("Not Found");
		else
			rb = Response.ok().entity(c);

		rb.cookie(new NewCookie("cook", "oatmeal")).header("name", "bubba");
		
		return rb.build();

	}
}
