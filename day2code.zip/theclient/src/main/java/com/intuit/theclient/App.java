package com.intuit.theclient;

import java.util.Collection;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//http://localhost:8080/weds/car/bubba
        Client c = ClientBuilder.newClient();
        WebTarget wt=c.target("http://localhost:8080/weds/car");
        WebTarget resource=wt.path("bubba");
        
        Response r=resource.request(MediaType.APPLICATION_XML).
        		header("intuit-auth","ok").get();
        System.out.println(r.getStatus());
        
        Collection<Car> cars=r.readEntity(Collection.class);
        System.out.println(cars);
        
        
    }
}
