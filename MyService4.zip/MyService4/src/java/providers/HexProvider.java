package providers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

@Provider
public class HexProvider implements MessageBodyReader<Integer>, MessageBodyWriter<Integer> {

    @Override
    public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
        boolean rv =  ((type == Integer.class) || (type == Integer.TYPE))
                && "application/hex".equalsIgnoreCase(
                mediaType.getType() + "/" + mediaType.getSubtype());
        return rv;
    }

    @Override
    public Integer readFrom(Class<Integer> type, Type genericType,
        Annotation[] annotations, MediaType mediaType, 
        MultivaluedMap<String, String> httpHeaders, 
        InputStream entityStream) throws IOException, WebApplicationException {
        BufferedReader br = new BufferedReader(new InputStreamReader(entityStream));
        return Integer.parseInt(br.readLine(), 16);
    }

    @Override
    public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
        boolean rv =  ((type == Integer.class) || (type == Integer.TYPE))
                && "application/hex".equalsIgnoreCase(
                mediaType.getType() + "/" + mediaType.getSubtype());
        return rv;
    }

    @Override
    public long getSize(Integer t, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
        String hex = Integer.toHexString(t);
        return hex.length();
    }

    @Override
    public void writeTo(Integer t, Class<?> type, Type genericType, 
        Annotation[] annotations, MediaType mediaType, 
        MultivaluedMap<String, Object> httpHeaders, 
        OutputStream entityStream) throws IOException, WebApplicationException 
    {
        String hex = Integer.toHexString(t);
        PrintWriter pw = new PrintWriter(new OutputStreamWriter(entityStream));
        pw.print(hex);
        pw.flush();
    }
}
