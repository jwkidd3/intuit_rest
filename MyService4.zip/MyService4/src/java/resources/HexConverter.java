package resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("hex")
public class HexConverter {
    @POST
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes("application/hex")
    public Response number(int input) {
        return Response.ok("" + input).build();
    }

    @POST
    @Produces("application/hex")
    @Consumes(MediaType.TEXT_PLAIN)
    public Response hex(String input) {
        return Response.ok(Integer.parseInt(input)).build();
    }
}
