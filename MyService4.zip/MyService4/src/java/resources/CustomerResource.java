package resources;

import entity.Customer;
import entity.Supplier;
import entity.CustomerTable;
import entity.RelationshipTable;
import entity.SupplierTable;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

@Path("Customers")
public class CustomerResource {
    
    private static final Pattern SEARCH_PATTERN = Pattern.compile("(\\w+)\\.(\\w+)\\.(.+)");
    private static final String UUID_PATTERN = "\\p{XDigit}{8}"
            + "-\\p{XDigit}{4}-\\p{XDigit}{4}-\\p{XDigit}{4}"
            + "-\\p{XDigit}{12}";
    @Context
    private UriInfo context;
    
    public CustomerResource() {
    }
    
    @GET
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getCustomers(@QueryParam("query") String query,
            @HeaderParam("Accept") String accept) {
        accept = accept.toLowerCase();
        System.out.println("Accepting: " + accept);
        StringBuilder sb = new StringBuilder();
        List<Customer> lc = null;
        if (query == null) {
            lc = CustomerTable.getAll();
        } else {
            Matcher m = SEARCH_PATTERN.matcher(query);
            if (m.matches()) {
                String field = m.group(1);
                String operation = m.group(2);
                String operand = m.group(3);
                lc = CustomerTable.findByFieldMatch(field, operation, operand);
            } else {
                sb.append("Badly formed search parameter...");
            }
        }
        return Response.ok(
                new GenericEntity<List<Customer>>(lc) {
        }).build();
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Produces(MediaType.TEXT_PLAIN)
    public Response createCustomer(Customer c) {
        System.out.println("Creating new Customer entry for " + c);
        UUID id = CustomerTable.insert(c);
        return Response.created(context.getRequestUriBuilder().path(id.toString()).build()).build();
    }
    
    @PUT
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Produces(MediaType.TEXT_PLAIN)
    public Response updateCustomer(Customer c) {
        System.out.println("Updating Customer entry for " + c.getId());
        URI location = context.getRequestUriBuilder().path(c.getId().toString()).build();
        if (CustomerTable.update(c)) {
            return Response.ok(location.toString()).build();
        } else {
            return Response.created(location).entity(location.toString()).build();
        }
    }
    
    @GET
    @Path("{id: " + UUID_PATTERN + "}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response getOneCustomer(@PathParam("id") UUID id) {
        ResponseBuilder r;
        Customer c = CustomerTable.findByPrimaryKey(id);
        if (c != null) {
            r = Response.ok(c);
        } else {
            r = Response.status(404).entity("That entry does not exist");
        }
        return r.build();
    }
    
    @DELETE
    @Path("{id: " + UUID_PATTERN + "}")
    public void deleteOneCustomer(@PathParam("id") UUID id) {
        CustomerTable.removeByPrimaryKey(id);
    }
    
    @Path("{custId: " + UUID_PATTERN + "}/Supplier/{supplierIdx: \\d+}")
    public Supplier getOneSupplier(@PathParam("custId") UUID custId,
            @PathParam("supplierIdx") int supplierIdx) {
        return RelationshipTable
                .findSuppliersOfCustomer(custId)
                .get(supplierIdx);
    }
    
    @POST
    @Path("{custId: " + UUID_PATTERN + "}/Supplier/{supplierId: " + UUID_PATTERN + "}")
    public Response createRelationship(@PathParam("custId") UUID custId,
            @PathParam("supplierId") UUID supplierId) {
        if ((CustomerTable.findByPrimaryKey(custId) != null)
                && (SupplierTable.findByPrimaryKey(supplierId) != null)) {
            RelationshipTable.newRelationship(custId, supplierId);
            return Response.noContent().build();
        } else {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Customer or Supplier ID was not found")
                    .type(MediaType.TEXT_PLAIN)
                    .build();
        }
    }
}
