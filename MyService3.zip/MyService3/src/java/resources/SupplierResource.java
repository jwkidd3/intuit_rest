package resources;

import entity.Supplier;
import entity.SupplierTable;
import java.util.List;
import java.util.UUID;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("Suppliers")
public class SupplierResource {

    @Context
    private UriInfo uriInfo;

    public SupplierResource() {
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getSuppliers() {
        List<Supplier> ls = SupplierTable.getAll();
        StringBuilder sb = new StringBuilder();
        if (ls != null) {
            sb.append("<HTML><BODY><UL>\n");
            for (Supplier s : ls) {
                String newURI = uriInfo.getAbsolutePathBuilder()
                        .path("" + s.getId().getLeastSignificantBits())
                        .build()
                        .toString();
                sb.append("<LI><A HREF=\"")
                        .append(newURI)
                        .append("\">")
                        .append(s.getId())
                        .append("</A>")
                        .append("</LI>\n");
            }
            sb.append("</UL></BODY></HTML>");
        }
        return sb.toString();
    }
    
    @Path("{id: \\d+}")
    public Supplier getSupplier(@PathParam("id") int id) {
        return SupplierTable.findByPrimaryKey(new UUID(0, id));
    }
}
