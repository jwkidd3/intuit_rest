package myclient;

import entity.Customer;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;

public class MyClient {

    public static void main(String[] args) {
        Client c = ClientBuilder.newClient();
        c.register(JacksonJsonProvider.class);
        WebTarget root = c.target("http://localhost:8080/MyService4/v1/Customers");
        WebTarget t = root.path("00000000-0000-0000-0000-000000000001");
        Invocation.Builder ib = t.request(MediaType.APPLICATION_JSON);
        Response resp = ib.get();
        System.out.println("Status code is " + resp.getStatus());
        Customer cust = resp.readEntity(Customer.class);
        System.out.println("Customer is: " + cust);

        resp = root
                .request(MediaType.APPLICATION_XML)
                .get();
        
        System.out.println("Status code is " + resp.getStatus());
        GenericType<List<Customer>> gtlc = new GenericType<List<Customer>>(){};
        List<Customer> lc = resp.readEntity(gtlc);

        for (Customer cu : lc) {
            System.out.println("customer: > " + cu);
        }

        resp = root
                .request(MediaType.TEXT_PLAIN)
                .post(Entity.entity(new Customer(null, "New Customer Fred", "On this planet", 100), MediaType.APPLICATION_XML));
        System.out.println("Location is: " +resp.getHeaderString("Location"));
    }
}
